# Database Schema

Tables:
- Users (id, name, role, password)
- Courses (id, title, description)
- Enrollments (student_id, course_id, grade)
