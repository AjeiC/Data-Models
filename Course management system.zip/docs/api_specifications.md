# API Specifications

Endpoints (planned for future expansion):
- POST /login
- GET /courses
- POST /grades
