# Architecture Design

- MVC pattern (Model-View-Controller)
- JavaFX for GUI
- SQLite for local storage
