# System Requirements

- User roles: Admin, Student, Faculty
- Manage courses, grades, assignments
- Authentication system
