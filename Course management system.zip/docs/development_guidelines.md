# Development Guidelines

- Use feature branches
- Write clear commit messages
- Submit pull requests for all changes
