# University Course Management System

A system designed to help universities manage courses, student enrollments, grades, and faculty assignments.

## Core Features
- Course Management
- Student Management
- Faculty Management
- Authentication System
- Grade Recording and Computation
- Reporting System

## Technologies
Planned to be implemented in Java with JavaFX and SQLite.
